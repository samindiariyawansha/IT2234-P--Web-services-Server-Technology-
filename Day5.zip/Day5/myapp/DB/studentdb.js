//array of student JSON details
let students = [
    {regno:'2021ict40',name:'Ariyawansha',gender:'F',course:'IT'},
    {regno:'2021ict79',name:'Wijekoon',gender:'F',course:'IT'},
    {regno:'2021ict31',name:'nuwani',gender:'M',course:'IT'},
    {regno:'2021ict22',name:'Kadigamuwa',gender:'F',course:'IT'}
]

module.exports = students;
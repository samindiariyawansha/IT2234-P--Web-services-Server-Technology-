let  students = [
    {regno:"2021ICT01",Name:"Sawi",age:25,gender:"female"},
    {regno:"2021ICT02",Name:"Nuwani",age:24,gender:"female"},
    {regno:"2021ICT03",Name:"Abi",age:26,gender:"female"},
    {regno:"2021ICT04",Name:"Wijeykoon",age:25,gender:"male"},
    {regno:"2021ICT05",Name:"sithu",age:23,gender:"female"}
];
module.exports = students;